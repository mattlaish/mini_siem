# mini-SIEM

## Daily use

- **Live logs & alerts:** confirm incoming activity, search events and open their
  original evidence. Expand a row to add useful fields as filters or columns.
- **Alerts:** review open alerts, assign an owner, record findings and update status.
- **Investigations:** run a security playbook or follow related activity from an IP.
- **Detection Rules / Approved Hours:** tune alerts, test a sample and manage
  host-specific allowed times. Choose **Save changes** to activate edits.
- **Settings:** connect devices or cloud services. Use **Check log delivery** and
  **System Health** when an expected source stops reporting.
- **Help:** task-based guidance is available from every page. Administrators manage
  connections and settings; analysts handle alerts; viewers have read-only access.

The interface uses operator-facing labels; vendor protocol names, field names and
original evidence remain unchanged. [UX_REVIEW.md](UX_REVIEW.md) records the
2026-10-18 language pass, validation and next usability improvements. Installation
and administration details follow below.

## Design and operating documents

- `DETECTION_RULE_MANAGEMENT.md` — managed rules, Windows process/script fields,
  approved execution windows, scoped exceptions, telemetry receipt health and AI
  usage/cost estimates (2026-10-15 development slice).

- `DEVELOPMENT.md` — engineering contract, implementation state, and active Short/Medium/Long investigation state machine.
- `OPERATION.md` — SOC operating model for triggers, related evidence, progressive LLM escalation, and evidence handling.
- `PRODUCT.md` — product behavior and user-facing progressive investigation semantics.


A small self-contained SIEM: a syslog receiver on port 514 (UDP + TCP),
a parser for RFC3164 and RFC5424 formats, SQLite storage, a
correlation/alerting rule engine, and a web dashboard.

```
mini_siem/
  listener.py     syslog receiver + parser + storage + rule engine hookup
  rules.py        correlation rules (brute force, denies burst, severity)
  dashboard.py    Flask app shell + core routes
  web_blueprints/ AI, IOC feeds, DB health/backup, users, reports, tickets
  sql_helpers.py  allow-listed SQL composition helpers
  templates/
    index.html
  requirements.txt
```

## 1. Install dependencies

```bash
pip install -r requirements.txt
```

The listener itself has zero third-party dependencies (pure standard
library — socket, sqlite3, re). The dashboard uses Flask and is served by
Waitress rather than Flask's development server.

## 1b. Choose a database backend (do this before going live)

The SIEM can store everything in either backend — pick one up front:

- **SQLite** (default) — local, zero setup, one file. Great for a
  handful to a few dozen devices. Nothing to install or run.
- **PostgreSQL** — external server; real concurrent writes, scales well
  past SQLite's single-writer ceiling. Needs a reachable Postgres and
  the driver: `pip install psycopg2-binary`. PostgreSQL connections are reused through a
  small thread-safe pool (`pool_min` defaults to 1, `pool_max` defaults to 10
  under the `postgres` config object).

Run the interactive chooser:

```bash
python3 configure-db.py
```

It writes `db-config.json`, and for Postgres it tests the connection and
creates the tables so you know it works before starting. You can also
just edit `db-config.json` by hand:

```json
{
  "backend": "postgres",
  "sqlite":   { "path": "siem.db" },
  "postgres": { "host": "db.internal", "port": 5432,
                "dbname": "minisiem", "user": "minisiem", "password": "secret" }
}
```

All components (`siem.py`, `listener.py`, `dashboard.py`) read
`db-config.json` automatically. Switching backends points the SIEM at a
different store — it does **not** copy existing rows between them, which
is why the choice is best made before you start collecting. If you skip
this entirely, it defaults to SQLite at `siem.db` and everything just
works.

Note: SQLite remains the tested-by-default path in this build. The
PostgreSQL path is implemented through the same abstraction and verified
by construction; test it against your Postgres with `configure-db.py`
(which runs a real connect + table create) before relying on it.

## 1c. Authentication (login on the dashboard)

The dashboard now requires a login. Three methods, set in
`auth-config.json`, each independently enabled:

- **Local** (default, on) — username/password hashed in the DB. On
  first run it seeds **admin / admin** and *forces a password change*
  before anything else can be used. No extra packages needed.
- **OAuth / OIDC** — Google, Azure AD/Entra, Okta, Auth0, Keycloak, or
  any provider with a discovery URL. Needs `pip install authlib`.
- **SAML 2.0** — Okta, Azure AD, ADFS, etc. Needs
  `pip install python3-saml` plus system libs `xmlsec1`/`libxml2`.

First-run login:
1. Start the dashboard, open it — you'll get the login page.
2. Sign in with **admin / admin**.
3. You're immediately required to set a new password (min 8 chars, and
   it won't let you keep the default). After that the default is dead.

Enabling SSO — edit `auth-config.json`:

```json
{
  "local_auth": { "enabled": true },
  "oauth": {
    "enabled": true, "provider_name": "Okta",
    "discovery_url": "https://YOUR-DOMAIN/.well-known/openid-configuration",
    "client_id": "...", "client_secret": "...",
    "scopes": "openid email profile"
  },
  "saml": {
    "enabled": true,
    "sp_entity_id": "mini-siem",
    "sp_acs_url": "https://your-siem:8080/auth/saml/acs",
    "idp_entity_id": "...", "idp_sso_url": "...",
    "idp_x509cert": "MIIC...(IdP signing cert, no PEM header)"
  }
}
```

- OAuth redirect/callback URL to register at your IdP:
  `https://your-siem:8080/auth/oauth/callback`
- SAML SP metadata is served at `/auth/saml/metadata` once enabled; ACS
  is `/auth/saml/acs`. You can leave local auth on alongside SSO (handy
  for a break-glass admin) or turn it off once SSO works.

Security notes:
- Passwords are hashed (werkzeug pbkdf2); the session cookie is signed
  with a secret auto-generated and stored once in the DB. **Serve over
  HTTPS in production** (put nginx/Caddy with TLS in front, or a reverse
  proxy) so the session cookie can't be sniffed — the login is only as
  safe as the transport under it.
- State-changing dashboard requests require a per-session CSRF token. In
  production, also pin the public dashboard origin (the URL users see in
  their browser):
  ```bash
  export MINISIEM_ALLOWED_ORIGIN=https://siem.example.com
  ```
  Multiple public origins can be comma-separated in
  `MINISIEM_ALLOWED_ORIGINS`. Values must be exact origins (scheme, host, and
  non-default port when applicable), with no path. API-key log ingestion and
  the SAML assertion-consumer endpoint retain their own authentication and
  are intentionally exempt from browser CSRF validation.
- OAuth and SAML are implemented with established libraries (Authlib,
  python3-saml), not hand-rolled, because incorrect assertion/signature
  validation is a severe auth-bypass class. **They are verified by
  construction but were not tested against a live IdP in this build —
  test them against yours before relying on them.** Local auth is
  tested end-to-end.

## 2. Run the listener

### The "database is read-only" / having to chmod siem.db / "can't overwrite files, have to delete them every update"

If you see a read-only database error, keep having to `chmod`
`siem.db`, **or find you can't overwrite the code files on update and
have to delete them first**, the cause is the same: **file ownership
from running as root**. Binding port 514 needs elevation, so if you
first ran the listener with `sudo`, files got created owned by `root`.
When your normal user later tries to write the DB, or `cp` a new
`dashboard.py` over the old root-owned one, it's refused — deleting
works (that depends on *directory* permissions, which you have) but
overwriting doesn't (that depends on *file* ownership, which is root's).
That's why delete-then-copy works but replace doesn't. `chmod` loosens
permission bits but the ownership mismatch remains, so it recurs.

The preferred production fix is the **two-service installer** in section 10:
`install-services.sh` runs only the port-514 listener as root and automatically
creates a non-login `siem` service account for the Waitress dashboard/pollers.
Both share the `minisiem` group, and the installer keeps the SQLite/WAL state
writable without making your personal login account part of the service model.
This avoids running the web UI as root without forcing you to hand-manage DB
permissions.

For manual/test launches, either keep both processes under one consistent
identity, use the capability/redirect options below, or repair existing file
ownership before continuing. Do not solve recurring ownership problems with
`chmod 777`.

The point is ownership, not permission bits — `chown` once (or run as
one consistent user) and the read-only errors stop for good.


Port 514 is a **privileged port** on Linux/macOS — binding to it
requires elevated permission. Pick one:

**Option A — run as root (simplest, fine for testing):**
```bash
sudo python3 listener.py --db siem.db
```

**Option B — grant the Python binary permission to bind low ports, without running as root (Linux):**
```bash
sudo setcap 'cap_net_bind_service=+ep' $(readlink -f $(which python3))
python3 listener.py --db siem.db
```

*What that command actually does, piece by piece:*
- `setcap` — "set capability." Linux **capabilities** grant one specific
  root-like power to a program instead of full root — like handing over a
  single key rather than the master key.
- `cap_net_bind_service` — the only power being granted: "may bind
  low-numbered (privileged) network ports" (anything under 1024, e.g.
  syslog's 514). Nothing else — not file access, not process control.
- `=+ep` — the syntax for "turn this capability on" (effective + permitted).
- `$(which python3)` — finds where `python3` lives (e.g. `/usr/bin/python3`).
- `$(readlink -f ...)` — `python3` is usually a symlink to the real binary
  (e.g. `python3.12`); capabilities must be set on the real file, so this
  follows the link to it.

Put together: *"grant the real python3 binary the single ability to bind
low ports, and nothing else."* After running it, start the listener as your
normal user (no `sudo`) and it binds 514 fine. Because nothing runs as root,
no root-owned files get created — which also **fixes the "read-only
database" errors and the "can't overwrite files, have to delete them every
update" problem**, both of which come from root-owned files.

Caveat: this grants the capability to that Python interpreter for *any*
script it runs, system-wide — fine on a dedicated SIEM box, less ideal on a
shared one. The recommended production alternative is the two-service systemd
installer (`install-services.sh`): it keeps the dashboard unprivileged and runs
only the listener as root for port 514. It does not modify the system Python
capabilities. To undo a manual setcap grant later:
`sudo setcap -r $(readlink -f $(which python3))`.

**Option C — bind an unprivileged port and forward 514 to it (Linux, iptables):**
```bash
python3 listener.py --port 5514 --db siem.db
sudo iptables -t nat -A PREROUTING -p udp --dport 514 -j REDIRECT --to-port 5514
sudo iptables -t nat -A PREROUTING -p tcp --dport 514 -j REDIRECT --to-port 5514
```

**Option D — just use a high port** if you control the devices sending
logs and can point them at, say, 5514 instead of 514:
```bash
python3 listener.py --port 5514 --db siem.db
```

Full options:
```bash
python3 listener.py --host 0.0.0.0 --port 514 --protocol both --db siem.db
```
`--protocol` accepts `udp`, `tcp`, or `both` (default). Most network
gear (routers, firewalls, switches) sends syslog over UDP; some
security appliances and Linux boxes running rsyslog/syslog-ng can be
configured to send TCP for reliable delivery.

## 3. Point a device at it

- **rsyslog / syslog-ng (Linux)**: add a forwarding rule, e.g. in
  `/etc/rsyslog.d/50-forward.conf`:
  ```
  *.* @@your-siem-host:514      # TCP
  *.* @your-siem-host:514       # UDP
  ```
  then `sudo systemctl restart rsyslog`.
- **Network devices (firewalls, switches, routers)**: set the "syslog
  server" / "remote logging" address to your SIEM host's IP, port 514.
- **Test manually** with `logger`:
  ```bash
  logger -n your-siem-host -P 514 -d "test message from logger"
  ```

## 4. Run the dashboard

```bash
python3 dashboard.py --db siem.db --host 127.0.0.1 --port 8080
```
Then open `http://127.0.0.1:8080`. The command serves Flask through Waitress
(single process, threaded) rather than Werkzeug's development server. It polls
the same SQLite file the listener writes to, refreshing every 5 seconds. It's read-only and can
run on a different machine than the listener as long as it can reach
the `siem.db` file (e.g. on shared storage), or you point `--db` at a
copy/replica.

## 5. On-demand correlation & playbooks (/correlate)

**14 playbooks** across credential attacks, privilege abuse, malware,
network attacks, and tampering — including privilege escalation chains,
account-lockout storms (password spraying), AV/malware detections,
service-failure bursts, log-tampering indicators, and probe-then-allowed
firewall patterns.

**Playbook reports:** run every playbook over a 1/7/30/90-day window and
save the result as a report (viewable + downloadable JSON), on demand or
scheduled **weekly/monthly** — the scheduler runs inside the SIEM
process, no cron needed. Findings include the matched groups and each
playbook's response steps.

**Current scheduled-playbook behavior:** scheduled findings are stored as
reports only. The current `ReportScheduler` is not wired with an `on_report`
callback, so a scheduled finding does **not** currently create an alert, enter
LLM triage, or create a ticket. The intended future contract is deliberately
separate from AI triage: scheduled playbook finding -> alert -> ticket pipeline
(subject to the configured ticket severity threshold), while the playbook alert
itself should skip LLM analysis unless that behavior is explicitly redesigned.


The dashboard has a second page at `http://127.0.0.1:8080/correlate`.
It now combines playbooks/reports with a manual **Investigate** workspace rather
than exposing the old ad-hoc correlation form as the primary analyst workflow.

**Investigate an IP:** enter an IPv4/IPv6 address, then set two independent
sliders:

- **Investigation window:** `Short` = last 30 minutes, `Medium` = last 90 minutes,
  `Long` = last 5 hours. Manual investigation is retrospective and ends at the
  current time; alert-driven AI triage keeps its existing alert/profile-specific
  before/after windows.
- **Entity expansion:** `0..4` confirmed hops. `A -> B` alone does not promote
  `B`; `B` must later appear as `source_ip` inside the selected window. A second
  hop requires `B -> C` followed by later source activity from `C`, and so on.

Results show the effective time scope, admitted entities, confirmed pivot
transitions with relationship/proof event IDs, and the bounded evidence set.
Once an IP is admitted, evidence still matches it in source, destination,
`peer_ip`, or indexed endpoint/source/destination fields. Pivot discovery itself
remains stricter and server-controlled; the LLM gets no query authority.

The underlying `threshold`, `sequence`, `fanout`, and `first_seen` correlation
engine and `/api/correlate` endpoint remain available for playbooks and API
compatibility. The UI change does not remove the correlation engine.

**14 built-in playbooks** (`correlations.py`), each with a
description and suggested response steps shown alongside results:
brute force then success, Windows event log cleared, new
account/privileged group addition, scan fan-out, one account from many
IPs, off-hours privileged activity, never-before-seen source IPs, error
bursts, privilege-escalation attempts then success, account-lockout
storms, malware/AV detections, service-failure bursts, log-tampering
indicators, and blocked-then-allowed firewall probe patterns. Add your own
by appending to `PLAYBOOKS` — a playbook is engine parameters plus
documentation/response guidance.

Every result row links its evidence: sample messages inline, plus a
link that opens the exact matched events in the main log view.

## 6. Ticket system connector (/setup)

Automatically create a ticket for every alert at/above a chosen severity
— covers rule alerts, `threat_intel_match` IOC hits, everything in the
alerts table. Works with any REST ticket API (Jira, ServiceNow, Zammad,
osTicket, generic webhooks): set the URL, auth headers (write-only,
never echoed back), and a JSON body template with placeholders
(`{{rule_name}}`, `{{severity}}`, `{{description}}`, `{{source_ip}}`,
`{{ai_analysis}}`, ...). A background dispatcher sends each qualifying
alert once, records the returned ticket key on the alert, retries on
failure, and there's a "Send test ticket" button. Note: this makes
outbound HTTP calls from the SIEM to your ticket API.

The ticket worker consumes the `alerts` table directly; it does not require an
LLM result. Therefore, once scheduled playbook findings are wired to create
alerts, those alerts can create tickets without first entering LLM triage. That
scheduled-playbook -> alert wiring is **not implemented yet** in the current
runtime, so scheduled reports alone do not currently create tickets.

**Progressive AI investigation scope:** context collection is application-controlled. Short
stays on the trigger IP; Medium may pivot one hop and Long may pivot two hops,
but a related IP is promoted to a new pivot only after it subsequently appears
as a source in the same investigation window. Entity count and submitted event
count remain bounded. The LLM never receives database/query authority.

## 6a. SQLite message-search capability

SQLite FTS5 is treated as an optional search accelerator. At startup mini-SIEM
probes whether the active SQLite runtime can actually create an FTS5 virtual
table. When available, message search uses the maintained `logs_fts` index and
`MATCH`; when unavailable, startup and ingest continue normally and dashboard
message search uses escaped case-insensitive `LIKE`. Existing databases created
with FTS5 also remain writable if later opened by a SQLite runtime without
FTS5: FTS maintenance triggers are detached until capability returns.

## 6b. Message normalization (log search)

Click any log row to extract fields from its message: `key=value` and
`key: value` pairs are parsed automatically, and you can save custom
regex patterns (with named groups) for formats that don't use
key=value — e.g. `Failed password for (?P<user>\S+) from
(?P<src>[\d.]+)`. Patterns are validated on save and applied to any
message you expand.

**Extracted columns:** enter field names (comma-separated, up to 8) in
the normalization settings and each becomes a real column to the right
of Message — with a per-column filter box (substring, case-insensitive)
and click-to-sort headers (numeric-aware; missing values sort last).
Extracted fields are **materialized at ingest** into an indexed
`log_fields` table (same database — no second DB needed), so filtering
and sorting by extracted fields searches your ENTIRE history via
indexed lookups, with no scan cap. Requirements: a little extra disk
(one small row per field per log) and one habit — after adding or
changing patterns, click **Re-index existing logs** once so older logs
gain the new fields (new logs pick patterns up automatically within
seconds). Exports include the columns as `x_<name>` and honor the same
filters. SQLite now runs in WAL journal mode for much higher ingest
throughput (~4,500 ev/s with indexing in testing); you'll see
`siem.db-wal`/`siem.db-shm` files beside the DB — that's normal. Double-clicking an **alert** opens its related logs
in the log search view.

### How normalization works — the three layers

There are three distinct stages, each configured (or not) in a different place. Knowing which is which saves confusion:

**1. Field extraction (automatic, not configured per source).** Every incoming event has *all* its fields pulled into the searchable `log_fields` table:
- **JSON events (poller/API, e.g. Sophos):** every top-level JSON key becomes a field; a nested `source_info.ip` is surfaced as `endpoint_ip`.
- **key=value messages (e.g. Fortigate):** every `key=value` token in the message becomes a field.
- **Custom patterns:** admin-defined regex (named groups) add extra fields — saved from the log-search expand panel.

This layer is exhaustive and universal — it grabs everything, so any field is searchable even if it isn't promoted to a column. There's nothing to configure; it just runs.

**2. Built-in parsing (fixed, in code — not editable).** A few source-specific behaviors are hardcoded:
- **Fortigate (CEF/key=value):** `src=` fills the Net-source column (`source_ip`); `dst=` fills Destination. Note `FTNTFGTlevel` is Fortigate's *own* severity field — it is not the same as a mini-SIEM dashboard alert.
- **Windows / NXLog:** `EventID` maps to severity via a built-in table (e.g. 4625 = failed logon, 1102 = audit log cleared). The shipper reports facts; the SIEM assigns severity.
- **All sources:** timestamps are normalized to ISO-8601; `peer_ip` records the true network sender.

**3. Configured normalization (two editable tabs under /setup):**
- **Source field mapping** — per-source profiles that map a few chosen fields into the base columns (Host, Message, Severity, Timestamp). E.g. for Sophos, `location` → Host.
- **Search field aliases** — defines which field names count as the same *concept* for search and correlation. E.g. treat both Fortigate's `src` and Sophos's `endpoint_ip` as "source", so one Source search finds a machine regardless of which source reported it. This resolves at query time, so edits apply to all historical data immediately with no reindex. It's also what the correlation playbooks use to group events by identity across sources.

To see what fields actually exist in your data right now (e.g. to fill in an alias correctly), expand any log row in Log Search — every field is listed with its exact name and value.

## 6c. External IOC feeds (/threatintel)

Besides pasting, you can point the SIEM at a plain-text feed URL
(abuse.ch Feodo Tracker, URLhaus, Spamhaus DROP, or your own list) and
it downloads + imports the indicators — on demand ("Fetch now") or
auto-refreshed every 6h/daily/weekly. Duplicates are skipped on
re-fetch, and per-feed status shows when it last ran and what it added.
Note: feed fetching makes outbound HTTP requests from the SIEM.

## 6d. Audit trail (/audit)

Every administrative action in the SIEM itself is recorded server-side:
logins (successes AND failures, with the attempted username), logouts,
password changes, user creation/deletion, IOC and feed changes,
forwarder/AI/ticket configuration changes, and report runs — each with
the acting user and their client IP. Filter by user, action, or free
text. Secrets never enter the trail: config changes record WHICH keys
changed (e.g. "ai_api_key (updated)"), never the values.

## 6e. Database integrity & backups

Since the data lives in one SQLite file, it's worth monitoring and
backing up. Three pieces:

**On the Health page** — a "Database integrity" section shows a live
status (quick check on load), a **Check now** button (runs SQLite's full
`PRAGMA integrity_check`), a **Backup now** button (WAL-safe online
backup into `backups/`, then verifies the copy), and the DB/WAL file
sizes.

**`db-maintenance.sh`** — a standalone script for cron. Each run makes a
WAL-safe online backup, runs a full integrity check on the *copy*,
rotates to the newest N backups, and on failure shouts via stderr,
`logger`, optional email, and (optionally) a syslog line to the SIEM
itself so DB trouble shows up as an alert in your own dashboard. It does
NOT need the dashboard running and is safe while the SIEM is live.

```bash
# daily 03:00, keep 14 days, email on failure:
0 3 * * * KEEP=14 ALERT_EMAIL=you@example.com \
  /home/matt/siem123/mini_siem/db-maintenance.sh >> ~/siem-maint.log 2>&1
```
Override with env vars: `DB`, `BACKUP_DIR`, `KEEP`, `ALERT_EMAIL`,
`SIEM_SYSLOG` (e.g. `127.0.0.1:514`).

**Why online backup, never `cp`:** copying `siem.db` without its
`-wal`/`-shm` companions (or while it's being written) is the most
common way to corrupt a WAL database — likely what happened if you ever
saw `database disk image is malformed`. The `.backup` method and this
script avoid that entirely. Recovery if it does happen: restore the
newest verified backup, or `sqlite3 siem.db ".recover" | sqlite3 new.db`.

## 6f. Agents

**Linux** (`linux_agent/`) — ships journald + arbitrary log files to the SIEM
over UDP/TCP syslog, with journal-cursor resume, file-offset persistence,
rotation/truncation detection, and a heartbeat that feeds the "Silent
sources" card. Installs as a hardened, non-root systemd service:
`sudo ./install-linux-agent.sh --siem-host <SIEM-IP>`. Executed and tested
end-to-end (see linux_agent/README.md).

**Windows** (`windows_agent/`) — PowerShell agent + scheduled-task installer.
Static-checked only; never executed (no PowerShell in the build environment).

If a host already runs rsyslog, a one-line forward (`*.*  @siem:514`) may be
all you need — the agents are for journald cursors, file tailing, and
heartbeats.

## 7. Syslog forwarding (/setup)

The listener can relay every received message — the **original raw
syslog text, exactly as it arrived** — to one or more downstream
syslog receivers, in addition to storing it locally. Configure it at
`http://127.0.0.1:8080/setup`.

- **Hot-reload**: forwarder config lives in the shared SQLite DB
  (`forwarders` table). The listener re-reads it every ~5 seconds, so
  adding, editing, disabling, or deleting a destination takes effect
  without restarting anything.
- **Per-destination filters**: optionally forward only events at or
  above a minimum syslog severity, and/or only messages matching a
  regex. Blank filters forward everything. Events whose severity could
  not be parsed are treated as informational for filtering purposes.
- **Protocols**: UDP (fire-and-forget, standard syslog behavior) or
  TCP (newline framing, automatic reconnect; a failed send records
  `last_error` and drops that message — there is no buffering/replay).
- **Loop protection**: destinations pointing at the listener's own
  address and port are automatically skipped. Indirect loops
  (A→B→A) are *not* detected — don't build them.
- **Status**: the setup page shows per-destination forwarded counts
  (flushed by the listener every ~10s), last forward time, and last
  error, plus a Test button that sends one test message from the
  dashboard process.

Note the forwarded counters are updated by the *listener* process; if
only the dashboard is running, forwarders can be configured and tested
but nothing is relayed until the listener is up.

## 7. Alerting rules (rules.py)

Ships with:
- **ssh_bruteforce** — 5+ "failed password / auth failure / invalid
  user" events from the same IP within 60s → critical alert
- **firewall_deny_burst** — 20+ deny/block/drop events from the same
  IP within 60s → warning alert
- **repeated_login_failures** — 8+ generic login/access failures from
  the same IP within 120s → warning alert
- **high_severity_event** — any single log at warning/error/critical/alert/emergency
  severity → immediate alert that preserves the event's actual severity

Add your own by subclassing `Rule` (or reusing `ThresholdRule`) in
`rules.py` and appending it to `RuleEngine.rules`.

## 8. AI SOC analyst (/ai)

A fourth page connects the SIEM to a **local or explicitly configured external** LLM to speed up triage.
Local OpenAI-compatible servers (Ollama, LM Studio, llama.cpp, vLLM) continue to use `/chat/completions`.
For `https://api.openai.com/v1`, protocol `auto` selects the OpenAI Responses API (`/responses`); the protocol can be overridden per deployment. External mode is HTTPS-only by default and applies the configured outbound evidence-redaction policy immediately before transmission. The default external policy is `strict`: identifiers are masked and standard raw log-message/alert-description free text is removed. `identifiers` keeps event text while masking IP/hostname/identity values; `none` sends the bounded evidence unchanged.

Setup:
1. Install a runtime and pull a model, e.g. with Ollama:
   `ollama pull qwen2.5:7b` (a 7B-class model is a fine starting point;
   larger = better reasoning, slower).
2. Open `/ai`, expand **LLM connection**, set the endpoint and model:
   - Ollama: `http://localhost:11434/v1`, model `qwen2.5:7b`
   - LM Studio: `http://localhost:1234/v1`, model as shown in its UI
3. Leave **API protocol** on `Auto` unless the provider requires an override.
4. Click **Test connection**. Save.

What it does:
- **Automatic triage (proactive)** — when enabled, every eligible new alert is
  sent to the model *as it fires* and its analysis is attached to the
  alert automatically. Trigger policy is source-specific: NXLog Windows JSON
  events at `warning` or above create the dedicated `nxlog_severity_event`
  trigger, while `notice` and `informational` NXLog events are context-only.
  Firewall detections keep their existing rules and do **not** inherit the
  NXLog warning/error trigger policy. The pre-existing generic device-severity
  trigger remains limited to `critical`/`alert`/`emergency` for non-NXLog data.
  Once an alert is selected for LLM triage, trigger policy no longer limits
  evidence. The SIEM resolves the investigation IP and runs the implemented
  progressive related-evidence workflow: **Short first**, then Medium only when
  the Short LLM result is `NO_SUSPICIOUS`/`INSUFFICIENT`, then Long only when
  Medium returns the same. `SUSPICIOUS` stops widening immediately. Each stage
  searches its investigation-specific time window across NXLog, firewall/CEF,
  API/pollers (including indexed `endpoint_ip`), and other sources where the IP
  appears as source, destination, peer, or an indexed source/destination field.
  Related evidence is not severity-filtered. Long reduces repetitive raw events
  and supplies bounded pattern summaries. Runs in a background worker, off the ingest path,
  so it never slows log collection: the listener raises the alert
  instantly (marked `pending`) and the worker drains pending alerts to
  the LLM one at a time. If the LLM is off or unreachable, alerts wait
  and get analyzed once it's back (failed calls retry, then mark
  `error`). Toggle it and set a minimum severity on the AI page. The
  main alert feed shows a "✓ analysis" button on triaged alerts.
- **Triage an alert (manual)** — pick a recent alert; manual triage uses the
  same progressive Short -> Medium -> Long state machine as automatic triage,
  with cross-source related history for the resolved investigation IP, and asks the model for a
  structured assessment (summary, true/false-positive call with
  confidence, severity view, recommended actions, what to check next).
- **Ask about your logs** — a chat box; the server retrieves relevant
  events by keyword and passes them as evidence for the model to answer
  over.

Security model (why it's built this way):
- **Read-only.** The model never runs queries. The server assembles a
  bounded context (capped event count and message length) and passes it
  in. This removes the prompt-injection risk of letting a model act on
  attacker-controlled log text — and the system prompts explicitly tell
  the model to treat log contents as data, not instructions.
- **Local-first with explicit external egress.** With a local runtime, log data never leaves your infrastructure. External mode requires HTTPS by default, applies `strict` outbound evidence redaction by default, and OpenAI Responses requests explicitly set `store=false`. HTTP external mode is accepted only for an explicitly enabled loopback development exception (`MINISIEM_AI_ALLOW_INSECURE_LOOPBACK_EXTERNAL=1`).
- The AI's output is assistive, not authoritative; the page says so and
  every answer ends with a verify-before-acting reminder.
- The LLM API key is never echoed back to the browser and is not stored plaintext in the DB. The DB stores only ciphertext; the encryption master is an owner-only file outside the DB (`/var/lib/mini-siem/ai-secret-master.key` for systemd installs). Existing plaintext `ai_api_key` rows are migrated in place on first successful read.
- Provider usage is recorded in `ai_usage_audit` as metadata only: provider/protocol/model, request IDs, HTTP status, token counts, retry count, latency and error code. Prompt/evidence text, model output and API keys are not stored in that audit table.
- HTTP 429/transient 5xx and transient connection/timeout failures use bounded retry/backoff with a total request-time budget; `Retry-After`/`retry-after-ms` is honored when present. Responses API `failed` and `incomplete` states fail closed rather than being accepted as analyst output. Explicit provider refusals are surfaced as the model response, while a completed response with neither text nor refusal is treated as an error. External-provider HTTP redirects are refused so Authorization credentials and SIEM evidence are never automatically replayed to a redirected endpoint.

Config lives in the `app_config` table and is edited entirely from the
page — no restart needed. AI calls are made by the **dashboard**
process, so the LLM runtime needs to be reachable from wherever the
dashboard runs.

## 9. Threat intelligence / IOC matching (/threatintel)

Match every incoming log against your own indicator lists, live at
ingest. Supported indicator types: **IP, domain, URL, file hash**
(MD5/SHA1/SHA256 — auto-detected).

How matching works:
- IPs are checked against the event's source IP (including the real
  source lifted from `srcip=`/`Source IP:` fields by enrichment), the
  host field, and any IPs appearing in the message text.
- Domains/URLs are matched as substrings of the message; hashes are
  extracted from message text and looked up exactly.
- A hit records on the Threat Intel page **and raises a
  `threat_intel_match` alert** (with the severity you set per
  indicator), so it shows on the main dashboard and gets auto-triaged
  by the AI Analyst if that's enabled.

Managing indicators:
- **Add one** — value + optional type (auto-detected), threat name and
  alert severity.
- **Paste a feed** — one indicator per line, `#` comments, or CSV
  `value,type,threat` per line. Works with copy-pastes from abuse.ch
  (Feodo Tracker, URLhaus), Spamhaus DROP, or your own lists. Give the
  feed a name; re-importing skips duplicates, and "Delete this feed"
  removes the old set when you want to load an updated copy.
- Enable/disable or delete indicators individually. Changes take effect
  within ~5 seconds (the matcher hot-reloads; no restart).

Honest scope note: this matches indicators **you provide** — the SIEM
does not (yet) auto-download feeds from the internet on a schedule.
Pasting a feed weekly takes a minute; scheduled feed pulls are a natural
next step if you want them.

## 10. Recommended production install: two systemd services

The supported production layout keeps the privileged syslog socket separate
from the web surface:

```text
mini-siem-listener   root             listener.py    TCP/UDP 514
mini-siem-dashboard  siem (non-login) dashboard.py   Waitress 8080 + API pollers
```

The installer uses an application-local Python virtual environment. It reuses either
`/opt/mini_siem/.venv` or the legacy/current `/opt/mini_siem/venv` when present.
If neither exists, it creates `.venv` automatically and installs
`requirements.txt`. This prevents systemd from depending on a personal user's
`~/.local` Python packages.

Install or repair the services. No username or numeric UID is required:

```bash
cd /opt/mini_siem
sudo ./install-services.sh
```

The installer creates a dedicated system account named `siem` with a non-login
shell and a shared `minisiem` group. `mini-siem-dashboard` always runs as
`siem`; `mini-siem-listener` remains `root` only because TCP/UDP 514 is a
privileged port. Your personal account (for example `matt`) is not used by
either service.

`install-services.sh` prefers `.venv/bin/python3`/`python`, then
`venv/bin/python3`/`python`, and never uses system Python as the final service
runtime. If the selected project venv is missing Flask/Waitress, the installer
repairs its dependencies from `requirements.txt`. Re-running the installer is
the supported repair path for a partial systemd installation; it rewrites,
enables, restarts, and verifies both units.

On CentOS/RHEL with SELinux Enforcing, moving/copying the project from a home
directory can leave `/opt/mini_siem` incorrectly labeled `user_home_t`. That
causes systemd to fail before Python starts with `status=203/EXEC` and
`Permission denied`. The installer detects this stale label under `/opt` and
runs the safe default-label repair (`restorecon`). It never disables SELinux.
You can verify manually with:

```bash
getenforce
ls -Zd /opt/mini_siem
sudo restorecon -RFv /opt/mini_siem
```

A normal `/opt` deployment should not remain `user_home_t`; on the CentOS/RHEL
host tested during deployment troubleshooting it restored to `usr_t`.

Verify both services and ports:

```bash
sudo systemctl --no-pager -l status mini-siem-listener
sudo systemctl --no-pager -l status mini-siem-dashboard
sudo ss -lntup | grep -E ':514|:8080'
getent passwd siem
ps -eo user,group,pid,cmd | grep -E '[l]istener.py|[d]ashboard.py'
```

Expected process identity: `listener.py` is `root:minisiem`; `dashboard.py` is
`siem:minisiem`. The `siem` account should have a `nologin`/`false` shell.

Useful logs:

```bash
sudo journalctl -u mini-siem-listener -n 50 --no-pager
sudo journalctl -u mini-siem-dashboard -n 50 --no-pager
```

### Upgrading an existing SQLite installation

If the old installation uses SQLite, **move the whole `siem.db` file**, not
individual tables. `siem.db` contains the application data/state, including
`api_pollers`, `app_config`, users, logs, IOC feeds, source profiles, report and
ticket data, poller cursor/state, and the encrypted poller secret/master-key
records. Therefore there is no separate `api_pollers` + `app_config` migration
when the complete SQLite database is carried forward.

Safe migration pattern:

```bash
# 1. Stop the old writer(s) first.
sudo systemctl stop mini-siem 2>/dev/null || true
sudo systemctl stop mini-siem-listener 2>/dev/null || true
sudo systemctl stop mini-siem-dashboard 2>/dev/null || true

# 2. Back up the old DB.
cp -a /old/path/siem.db /old/path/siem.db.pre-upgrade

# 3. Put the old database into the new code tree.
cp -a /old/path/siem.db /opt/mini_siem/siem.db
```

After a clean shutdown, migrate the main `siem.db`; do **not** blindly copy
stale `siem.db-wal` or `siem.db-shm` files from a running/unclean instance.
If you cannot cleanly stop the old SQLite writer, use SQLite's online backup
mechanism instead of a raw copy.

If you also have deployment files such as `db-config.json` or
`auth-config.json`, review/carry them forward as appropriate. Do not overwrite
new program files with old code modules.

Then install dependencies/services and validate:

```bash
cd /opt/mini_siem
python3 -m venv .venv
./.venv/bin/pip install -r requirements.txt
sudo ./install-services.sh
sudo ss -lntup | grep -E ':514|:8080'
```

### Legacy combined service

`siem.py` and `install-service.sh` remain for compatibility. They are not the
preferred production deployment path. New deployments should use
`fresh-install.sh` / `install-services.sh`, which generate split non-login
service identities.

## 11. Service identity model

The supported split-service installer generates the listener unit as
`siem-listener` with only `CAP_NET_BIND_SERVICE`; it does **not** require a
root listener merely to bind port 514. The dashboard uses `siem`, and
PostgreSQL partition maintenance uses `siem-maintenance`. The generated units
apply systemd sandboxing and component-specific database credential access.

PostgreSQL installs also keep the application tree runtime-immutable and use separate OS groups for dashboard/listener/maintenance credential files; `minisiem` is a shared code/read-state group only. Use `tools/systemd_host_qualification.py` to capture target-host systemd/SELinux/reboot evidence.

Do not copy an old `User=root` listener example into a new deployment; use the
installer-generated units so capability and credential checks remain
deterministic.

## Notes and limitations

- SQLite is fine for low/medium volume (a handful of devices, a few
  hundred events/minute). For high-volume production use, swap
  `Storage` in `listener.py` for Postgres/ClickHouse/Elasticsearch —
  the insert interface is small and easy to re-implement.
- The rule engine's state (sliding windows) lives in memory and resets
  if the listener restarts. For durability across restarts, back the
  counters with a small persistent store.
- TCP ingest accepts newline-delimited messages and RFC6587
  octet-counted framing. One final newline-framed message is accepted at
  connection close even without a trailing LF. Per-frame buffering is capped
  at 1 MiB; oversized or truncated octet-counted frames are rejected rather
  than partially ingested.
- This is a lightweight/reference implementation, not a hardened
  Internet-facing service — run it inside your trusted network
  perimeter, not exposed directly to the internet.

## PostgreSQL Migration Notes

The PostgreSQL migration effort identified several operational requirements:

- backend migration must preserve application state
- schema handling must support existing databases
- administrator bootstrap behavior must be migration-safe
- deployment readiness requires both infrastructure and application validation

## PostgreSQL raw-log privilege boundary

For PostgreSQL production deployments, use split runtime identities instead of one shared owner credential:

```bash
python3 configure-db.py
python3 tools/postgres_privilege_boundary.py --db-config ./db-config.json
sudo ./install-services.sh
python3 tools/postgres_privilege_check.py --db-config ./db-config.json
```

This makes the `logs` table append-only for listener/dashboard identities. They can SELECT and INSERT events but cannot UPDATE, DELETE, or TRUNCATE raw logs. Only the dedicated maintenance identity has DELETE for archive hot-copy eviction. PostgreSQL schema migrations remain an explicit owner operation and are not performed by runtime services. See `SECURITY.md` and `INSTALLATION.md` for the full boundary and deployment requirements.

## Setup Troubleshoot

The Setup page includes a **Troubleshoot** tab for a bounded live packet check. Enter a sender IPv4/IPv6 address and mini-SIEM listens for four seconds for UDP/TCP packets from that source to the configured syslog listener ports. The result shows whether packets were seen, packet counts, protocol counts, and a few packet-header summaries; syslog payloads are not displayed.

This requires the root-owned helper installed by `sudo ./install-services.sh` and the host `tcpdump` package. On CentOS/RHEL: `sudo dnf install -y tcpdump`.

### Web Console operational observability (2026-09-13)

The Health page now reports the separate listener process heartbeat, PostgreSQL effective security/schema readiness, and archive/maintenance status. These surfaces are observation-only: owner migrations, DB privilege provisioning, archive execution, and raw-log eviction remain explicit CLI/maintenance operations. Setup uses the installed systemd listener service for restarts so component DB credentials are preserved.

## Operational incident diagnostics

Administrators now have a read-only incident workflow in the Web Console:
- **Health -> Incident diagnostics** aggregates database, listener, ingest, PostgreSQL security/schema, archive and syslog-socket state and shows dependency health.
- **Setup -> Troubleshoot** correlates the bounded packet capture with listener peer counters and newly stored peer-IP events across Network -> Listener -> Parser -> Storage -> Search.
- **Setup -> Support bundle** downloads a sanitized diagnostics tarball for escalation. Credentials, private keys, API secrets, raw events and copied service journals are excluded by design.

These features are observability only; owner migrations, privilege changes, archive maintenance and service restarts remain outside the Web Console.

P9 source-truth hardening (2026-09-28) additionally prevents a critical unknown runtime state from being summarized as healthy, redacts credential-bearing exception text before diagnostic exposure, and validates/sanitizes allow-listed support-bundle JSON before packaging. Live deployed incident/browser/support-bundle qualification remains deferred.


## Phase 12.4 Performance & Capacity Qualification
Status: IMPLEMENTED_TESTING_DEFERRED

## Source-truth guard

The repository includes `PLACEHOLDER_TRUTH_ALIGNMENT.md`, `PLACEHOLDER_TRUTH_INVENTORY.json`, and `tools/check_placeholder_truth.py`. Placeholder/design/scaffold Python and no-op `assert True` tests do not count as implementation or test evidence. The overall product remains `IMPLEMENTED_TESTING_DEFERRED`; current canonical status is in `ROADMAP.md`.

## PostgreSQL Event Storage v2 — 2026-09-19

Status: `IMPLEMENTED_TESTING_DEFERRED`

PostgreSQL deployments now retain `logs/log_fields` as the raw evidence plane
while writing a typed, time-partitioned `security_events` hot query projection
in the same ingest transaction.  The projection uses native `TIMESTAMPTZ`,
`INET`, integer ports and `JSONB`, preserves raw event text, and links to the
minimal observational `assets`/`identities` foundation.  PostgreSQL search uses
exact IP/CIDR, prefix host/destination and explicit-contains semantics instead
of default `%...%` matching.  Monthly partitions are pre-created by a bounded
maintenance function/timer using the maintenance DB identity, never the schema
owner.  See `EVENT_STORAGE_V2.md` for the schema, index, privilege, archive and
qualification boundaries.  IP-centered entity context and bounded multi-hop investigation are implemented; broader non-IP entity graph work remains a revisit item.

## Install vs upgrade entry points

Use `fresh-install.sh` for a new deployment and `upgrade-existing.sh` for an existing deployment. They are deliberately fail-closed and mutually exclusive. PostgreSQL fresh bootstrap is not an operator upgrade mechanism; the low-level `install-services.sh --bootstrap-postgres` switch is accepted only when invoked through the fresh-install entry point. Existing split-role PostgreSQL upgrades preserve listener/dashboard/maintenance credentials and use temporary owner authority only for backup, migration/backfill, and grants repair. Packaged fresh-install `--resume` now validates the complete immutable artifact manifest. Existing upgrades use a separate durable crash/reboot journal; if one is present, run the same package with `upgrade-existing.sh --recover-interrupted` rather than starting a second upgrade. After PostgreSQL schema migration, interrupted recovery completes the verified new-source cutover or fails closed to the P5 restore path; it does not silently start old code against the newer schema.



## Priority hardening and Alert Lifecycle — 2026-09-23

Status: `IMPLEMENTED_TESTING_DEFERRED`

Fresh PostgreSQL installs now preflight TCP/authenticated access, verify the
PostgreSQL `current_user`, and require superuser or both `CREATEDB` and
`CREATEROLE` before any bootstrap DDL. Interrupted fresh installs may use
`sudo ./fresh-install.sh --resume` only when a matching checkpoint proves the
same target/config/source; resume is not a force-install or upgrade path.

The split systemd deployment runs the listener as `siem-listener` with only
`CAP_NET_BIND_SERVICE`, dashboard as `siem`, and PostgreSQL maintenance as
`siem-maintenance`, with component credential separation and additional
`NoNewPrivileges`/capability bounding.

Alerts now have a lightweight durable lifecycle (`new`, `acknowledged`,
`investigating`, `resolved`, `closed`) with assignment, history and audit.
Scheduled weekly/monthly playbook findings enter this same alert path and are
idempotently recovered if report creation committed before alert emission.
Existing TicketWorker integrations remain the external case/SOAR handoff.
mini-SIEM is **not** being expanded into a full case-management/SOAR product.


## 2026-09-23 source-gap closure: P1B / P5 / P6 / P8 / P13

The current development source implements the previously identified source gaps:
controlled legacy PostgreSQL shared-role -> split-role conversion, a dedicated
PostgreSQL backup/restore workflow, a real performance qualification runner, runtime
CEF parser wiring with executable E2E regression coverage, and a fail-closed final
release/provenance gate. These implementations remain
`IMPLEMENTED_TESTING_DEFERRED`; real PostgreSQL/systemd/browser/provider/network and
24h/72h production qualification gates are not implied by the local implementation
results. Full case management, SOAR expansion, HA and a replacement detection
framework remain outside this slice.

## 2026-09-23 P5 backup / restore source-truth audit

P5 remains `IMPLEMENTED_TESTING_DEFERRED`. PostgreSQL backup/restore now strictly validates immutable backup metadata and uses the current deployment owner for recovery; historical supported ledgers are restored as migration-required rather than runtime-ready. SQLite Web/cron backups now fail closed on integrity problems and use private, non-overwriting backup files. Live recovery/RPO/RTO qualification remains deferred.

## Dashboard integration return — 2026-10-22

The rebuilt delivery is `return/mini-siem-return-package.zip`, with SHA-256 and a
separate final offline audit alongside it. It contains the complete current safe
source, not only Markdown or an old partial overlay. Start with
`return/mini-siem/HANDOFF.md` for replay, installation and limitations.

This is a read-only, unqualified integration: fixture replay succeeds, but it does
not enable a live Dashboard connection. Existing PostgreSQL deployments must run
owner schema initialization and refresh runtime grants before restart. Keep local
credentials/configuration; never run the web dashboard as root. See
`return/mini-siem/open-gaps.md` before considering production enablement.
